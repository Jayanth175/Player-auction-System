const NewsTitle = ({ title }) => {
  return <div className="news-content-title">{title}</div>;
};

export default NewsTitle;
