const NewsDescription = ({ description }) => {
  return <div className="news-content-desc">{description}</div>;
};

export default NewsDescription;
